const express = require('express');
const path    = require('path');
const fs      = require('fs');
const router  = express.Router();

const VISITS_FILE   = path.join(__dirname, '..', 'data', 'visits.json');
const MESSAGES_FILE = path.join(__dirname, '..', 'data', 'messages.json');

function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return fallback; }
}
function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function renderPage(res, filename, data = {}) {
  const filePath = path.join(__dirname, '..', 'views', filename);
  fs.readFile(filePath, 'utf8', (err, html) => {
    if (err) return res.status(500).send('Error loading page.');
    Object.keys(data).forEach(key => {
      html = html.split(`{{${key}}}`).join(data[key]);
    });
    res.send(html);
  });
}

// GET /
router.get('/', (req, res) => {
  const visits = readJSON(VISITS_FILE, { count: 0 }).count;
  renderPage(res, 'index.html', { visits });
});

// GET /about
router.get('/about', (req, res) => {
  const visits = readJSON(VISITS_FILE, { count: 0 }).count;
  renderPage(res, 'about.html', { visits });
});

// GET /contact
router.get('/contact', (req, res) => {
  const visits = readJSON(VISITS_FILE, { count: 0 }).count;
  renderPage(res, 'contact.html', { visits, message: '', error: '' });
});

// POST /contact
router.post('/contact', (req, res) => {
  const { name, email, subject, body } = req.body;
  const visits = readJSON(VISITS_FILE, { count: 0 }).count;

  if (!name || !email || !body) {
    return renderPage(res, 'contact.html', {
      visits,
      message: '',
      error: '<div class="form-error">Please fill in all required fields.</div>'
    });
  }

  const messages = readJSON(MESSAGES_FILE, []);
  messages.push({
    id: Date.now(),
    name: name.trim(),
    email: email.trim(),
    subject: (subject || '').trim(),
    body: body.trim(),
    date: new Date().toISOString()
  });
  writeJSON(MESSAGES_FILE, messages);

  renderPage(res, 'contact.html', {
    visits,
    message: `<div class="form-success">Thank you, ${name.trim()}! Your message has been received.</div>`,
    error: ''
  });
});

// GET /api/visits
router.get('/api/visits', (req, res) => {
  const visits = readJSON(VISITS_FILE, { count: 0 });
  res.json({ visits: visits.count, timestamp: new Date().toISOString() });
});

// GET /api/messages
router.get('/api/messages', (req, res) => {
  const messages = readJSON(MESSAGES_FILE, []);
  res.json({ total: messages.length, messages });
});

module.exports = router;
